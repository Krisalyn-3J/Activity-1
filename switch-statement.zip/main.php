<?php
$favdrink = "pineapple";

switch ($favdrink) {
    case 'pineapple':
        echo "Your favorite drink is pineapple!";
        break;
        case 'orange':
            echo "Your favorite drink is orange!";
    break;
    case 'apple':
        echo "Your favorite drink is apple! ";
        break;
    default:
        echo "Your favorite drink is neither pineapple, orange, nor apple!";
        break;
}

