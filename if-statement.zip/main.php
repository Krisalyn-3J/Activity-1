<?php

if (7>3) {
    echo "Welcome to php!";
    
}
?>


