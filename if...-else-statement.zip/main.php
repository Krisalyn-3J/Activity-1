<?php

$t = time ("T");
if ( $t < "10") {
    echo "Have a good day!";
    
} else {
    echo " Have a goodnight!";
}

